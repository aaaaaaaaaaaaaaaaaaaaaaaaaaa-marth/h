package api

type (
	ChangePlayerRequest struct {
		StatefulRoom
		Index int `json:"index"`
	}
	ChangePlayerResponse int
	GameQuitRequest      StatefulRoom
	LoadGameRequest      StatefulRoom
	LoadGameResponse     string
	ResetGameRequest     StatefulRoom
	ResetGameResponse    string
	SaveGameRequest      StatefulRoom
	SaveGameResponse     string
	StartGameRequest     struct {
		StatefulRoom
		Record      bool
		RecordUser  string
		Game        string `json:"game"`
		PlayerIndex int    `json:"player_index"`
	}
	GameInfo struct {
		Alias  string `json:"alias"`
		Base   string `json:"base"`
		Name   string `json:"name"`
		Path   string `json:"path"`
		System string `json:"system"`
		Type   string `json:"type"`
	}
	StartGameResponse struct {
		Room
		AV      *AppVideoInfo `json:"av"`
		Record  bool          `json:"record"`
		KbMouse bool          `json:"kb_mouse"`
	}
	RecordGameRequest struct {
		StatefulRoom
		Active bool   `json:"active"`
		User   string `json:"user"`
	}
	RecordGameResponse      string
	TerminateSessionRequest Stateful
	WebrtcSignalRequest     struct {
		Stateful
		Sdp *string `json:"sdp,omitempty"`
		Ice *string `json:"ice,omitempty"`
	}
	InitWebrtcStreamRequest struct {
		// Stateful
		Id        string `json:"id"`
		Initiator bool   `json:"initiator"`
		Sdp       string `json:"sdp,omitempty"`
	}
	InitWebrtcStreamResponse string

	AppVideoInfo struct {
		W    int     `json:"w"`
		H    int     `json:"h"`
		A    float32 `json:"a"`
		S    int     `json:"s"`
		SM   string  `json:"sm,omitempty"`
		Flip bool    `json:"flip"`
		Rot  uint    `json:"rot"`
	}

	LibGameListInfo struct {
		T    int
		List []GameInfo
	}

	PrevSessionInfo struct {
		List []string
	}
)
